if GetLocale() ~= "esMX" then return end
